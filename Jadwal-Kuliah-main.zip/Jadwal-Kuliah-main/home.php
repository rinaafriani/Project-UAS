<style type="text/css">
<!--
.style1 {
	font-family: "Monotype Corsiva";
	font-size: 18px;
}
.style2 {font-family: "Trebuchet MS";
}
.style4 {font-size: 16px}
-->
</style>
<span class="style1"><marquee>Welcome to Sistem Informasi Penjadwalan Mata Pelajaran</marquee></span>
<hr>
<div align="justify" >&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<br />
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Web dibuat sebagai media informasi dan komunikasi yang efektif <br />
  </span></p>
<div align="justify" >Terima kasih kami sampaikan  kepada semua pihak, semoga Web ini dapat bermanfaat dan berguna sebagai mana  mestinya. dan kami selalu menunggu saran dan masukan.</div>
</div>
<br><br><br><br><br><br>