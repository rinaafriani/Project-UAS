<?php 
	include "config/koneksi.php";
	include "config/fungsi_indotgl.php";
	include "config/fungsi_kalender.php";
	include "config/class_paging.php";
	include "config/library.php";
	include "view/index.php"; 
?>
