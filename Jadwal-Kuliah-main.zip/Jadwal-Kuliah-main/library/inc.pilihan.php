<?php
// Membuat daftar pilihan Pekerjaan pada ComboBox
$pekerjaan		= array();
$pekerjaan[]	= "Pegawai Negri Sipil (PNS)";
$pekerjaan[]	= "Karyawan";
$pekerjaan[]	= "Buruh";
$pekerjaan[]	= "Petani";
$pekerjaan[]	= "Nelayan";

// Membuat daftar pilihan Pendidikan
$pendidikan		= array();
$pendidikan[]	= "SMA";
$pendidikan[]	= "Sarjana";
$pendidikan[]	= "Pasca Sarjana";
$pendidikan[]	= "Profesor";

// Membuat daftar pilihan Status Guru
$statusGuru		= array();
$statusGuru[]	= "Guru PNS Kemendikbud";
$statusGuru[]	= "Guru PNS Kemenag";
$statusGuru[]	= "Guru Honorer Sekolah Negeri";
$statusGuru[]	= "Guru Tetap Yayasan";
$statusGuru[]	= "Guru Tidak Tetap Yayasan";
$statusGuru[]	= "Guru PNS Diperbantukan di Sekolah Swasta";
$statusGuru[]	= "Guru PTT (Pegawai Tidak Tetap) Pemda";
$statusGuru[]	= "Guru SM3T"; // Sarjana Mendidik di Daerah Terdepan, Terluar dan Tertinggal
$statusGuru[]	= "Guru Ngaji";

// Membuat daftar pilihan Golongan
$golongan		= array();
$golongan[]		= "III A";
$golongan[]		= "III B";
$golongan[]		= "III C";
$golongan[]		= "IV A";

?>